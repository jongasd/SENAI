print("Desafio")
print("Olá, usuário, me de um número e eu vou contar quantos dígitos tem o número fornecido.")
num = input("Me de um número")
def soma_digitos(num):
        return len(num)
print("O numero", num, "tem", soma_digitos(num),"dígitos")
