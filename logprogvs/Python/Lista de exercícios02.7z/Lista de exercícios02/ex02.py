print("Exertício 2")
print("Ola usuário, vou fazer a conta da soma dos primeiros 50 números pares")
n = 2
for i in range (2, 101, 2):
    n = n + i
print("A soma dos primeiros 50 números pares é", n)