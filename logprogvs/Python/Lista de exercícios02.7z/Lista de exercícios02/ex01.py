print("Exercício 1")
print ("Ola usuário vou lhe mostrar todos os números de 1 a 50 e depois vou lhe mostrar de forma invertida")
for i in range(1, 51):
    print(i)
for i in range(50, 0, -1):
    print(i)