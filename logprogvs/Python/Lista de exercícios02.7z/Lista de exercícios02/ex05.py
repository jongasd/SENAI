print("Exercício 5")
print("Ola usuário, vou lhe mostrar a tabuada de 0 a 9.")
for i in range(0, 10):
    print("Tabuada do", i)
    for j in range(0, 10):
        print(i, "x", j, "=", i * j)