#-*- coding: UTF-8 -*-
print('Exercicio 4')
print('Ola Usuário, me de um número, eu vou analisar se ele é par ou impar.')
num = int(input("Me de um número"))
if num % 2 == 0:
    print("O número é par")
else:
    print("O número é impar")