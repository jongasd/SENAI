#-*- coding: UTF-8 -*-
print('Exercicio 5')
print('Ola Usuário, me de um número, eu vou analisar se ele é divisível 3.')
num = float(input("Me de um número"))
if num % 3 == 0:
    print("O número é divisível por 3")
else:
    print("O número nao é divisível por 3")