// ─────────────────────────────────────────────────────────────────────────────
// cadastrarProduto(dados)                                               NEW
// Aula 10: POST /produtos — envia um novo prato para o banco de dados.
//
// "dados" é um objeto com: { nome, descricao, preco, categoria, imagem }
// O campo "imagem" é opcional (pode ser null) — o back-end trata adequadamente.
//
// Estratégia de imagem adotada: URL externa.
//   "dados.imagem" é uma string com a URL completa (ex: "https://...jpg").
//   O servidor salva a URL no banco — sem lidar com arquivos binários.
//   Para upload de arquivo, seria necessário FormData e multer no back-end
//   (referência comentada no cadastro.js).
//
// Por que o preço não é validado aqui?
//   O back-end valida — nunca confia no front-end.
//   cadastro.js valida antes de chamar esta função (UX imediata).
//   Duas camadas de validação: front (feedback rápido) + back (segurança).
// ─────────────────────────────────────────────────────────────────────────────
async function cadastrarProduto(dados) {
  const response = await fetch(`${BASE_URL}/produtos`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(dados),
  });
  const resposta = await response.json();
  if (!response.ok) throw new Error(resposta.erro || `Erro ${response.status}`);
  return resposta;
}
